export interface LoginDetails {
    jwt:string,
    email:string,
}