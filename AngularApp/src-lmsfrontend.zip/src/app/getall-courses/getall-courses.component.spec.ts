import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetallCoursesComponent } from './getall-courses.component';

describe('GetallCoursesComponent', () => {
  let component: GetallCoursesComponent;
  let fixture: ComponentFixture<GetallCoursesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetallCoursesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetallCoursesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
