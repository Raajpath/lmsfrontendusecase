export interface courseResponseDTO{
    courseName:string;
    courseDuration: string;
    courseDescription:string;
    technology:string[];
    launchUrl:string;
}