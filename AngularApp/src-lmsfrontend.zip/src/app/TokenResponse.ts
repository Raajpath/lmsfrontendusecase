export interface TokenResponse {
    emailId:string,
    role:string[],
    isTokenValid:boolean,
    isExpired:boolean
}