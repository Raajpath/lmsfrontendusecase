export class CourseDTO{
    courseName:string='';
    courseDuration:string='';
    courseDescription:string='';
    technology:string[]=[];
    launchUrl:string='';
}
